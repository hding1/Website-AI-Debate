Read Me

This is a project for writing 50. 

The purpose of this website is to solve problems, raise awareness, and gain influence over artificial intelligence issue.
This website includes most of materials created for the final project.

Instruction:
Click index.html to start visiting our site through default web-browser.
(Or any html to direct to the content page)
There is a navigation bar which directs you to all materials posted.

Folder:
Content Folder - includes all our paper works(essay etc..)
Poster Folder - includes all poster made by our members
Image Folder - includes all images we get from online
Style Folder - css files
JS Folder - javascirpts

Each group member worked on eight different materials 

Peter Ding – a website and a paper analyzing relation between AI and economy
Ziang Gao – infographics and a paper analyzing the safety concern of AI
Xingyu Zhao – a poster and a paper favor AI benefits
Yingchao Zhu – a poster and debating texts

Thanks to our professor, Kevin Moore, for this opportunity to present our idea.

We created our Prezi slides together at: https://prezi.com/view/OSG630MbTp201ykhDNd5/

My GitHub page: https://github.com/hding1/Website-AI-Debate

Thank you for visiting our website!

The website is designed and created by Peter Ding.

